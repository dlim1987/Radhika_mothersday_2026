Mamma's Mother's Day Adventure v17 - publish package

Contents:
- mammas-mothers-day-adventure-v17.html
- assets/ (all required photos)

Quick publish with GitHub Pages:
1. Create a new public GitHub repository.
2. Upload the HTML file and the assets folder to the root of the repository.
3. In GitHub: Settings > Pages > Build and deployment > Source = Deploy from a branch.
4. Select your main branch and /(root), then Save.
5. Wait a minute for the site to go live.
6. Open the GitHub Pages URL and test the full game.

Important: keep the HTML file and assets folder together.
